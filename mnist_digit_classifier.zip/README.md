# MNIST Handwritten Digit Recognition

A simple CNN model using TensorFlow to classify handwritten digits from the MNIST dataset.

## Accuracy
Achieved ~98% accuracy on test set.

## Tech Stack
- TensorFlow
- Keras
- Python
- Matplotlib

## To Run:
```bash
python mnist_cnn.py
```
